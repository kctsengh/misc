package hostsubnet

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime/schema"
)

var gvr = schema.GroupVersionResource{
	Group:    "egressha.com",
	Version:  "v1",
	Resource: "hostsubnets",
}

type HostsubnetSpec struct {
	Hostname    string   `json:"host_name"`
	HostIP      string   `json:"host_ip"`
	EgressCIDRs []string `json:"egress_cidrs"`
	EgressIPs   []string `json:"egress_ips"`
	Status      string   `json:"status"`
}

type Hostsubnet struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitemty"`
	Spec              HostsubnetSpec `json:"spec"`
}

type HostsubnetList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []Hostsubnet `json:"items"`
}

type HostActionInfo struct {
	Status           string
	IP               string
	EgressCIDRs      []string
	CurrentEgressIPs []string
	ToBeEgressIPs    []string
	EgressIPs_to_add []string
	EgressIPs_to_del []string
}

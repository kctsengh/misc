#!/bin/bash
set -e
go build -o hello
docker cp hello c1-control-plane:/root/go-code/helloworld/hello

docker cp hello c1-worker:/root/go-code/helloworld/hello


kubectl rollout restart deploy webhook-server
sleep 2 
kubectl get pod 

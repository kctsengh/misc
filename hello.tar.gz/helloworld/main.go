package main

import (
	"context"
	"flag"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
	"time"

	ciliumv2 "github.com/cilium/cilium/pkg/k8s/client/clientset/versioned/typed/cilium.io/v2"

	//mv1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	//	ciliumk8sClient "github.com/cilium/cilium/pkg/k8s/client"
	v2 "github.com/cilium/cilium/pkg/k8s/apis/cilium.io/v2"
	slimv1 "github.com/cilium/cilium/pkg/k8s/slim/k8s/apis/meta/v1"
	"github.com/rs/zerolog/log"
	admission "k8s.io/api/admission/v1"
	appsv1 "k8s.io/api/apps/v1"
	v1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	cv1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/runtime"

	"encoding/json"

	"k8s.io/apimachinery/pkg/runtime/serializer"
	"k8s.io/client-go/kubernetes"
	scheme "k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
)

var (
	runtimeScheme = runtime.NewScheme()
	codecFactory  = serializer.NewCodecFactory(runtimeScheme)
	deserializer  = codecFactory.UniversalDeserializer()
)

type Spec struct {
	EgressIP []string `json:"egress_ips"`
}
type Hs struct {
	Spec Spec `json:"spec"`
}

// add kind AdmissionReview in scheme
func init() {
	_ = corev1.AddToScheme(runtimeScheme)
	_ = admission.AddToScheme(runtimeScheme)
	_ = v1.AddToScheme(runtimeScheme)
}

type admitv1Func func(admission.AdmissionReview) *admission.AdmissionResponse

type admitHandler struct {
	v1 admitv1Func
}

func AdmitHandler(f admitv1Func) admitHandler {
	return admitHandler{
		v1: f,
	}
}

// serve handles the http portion of a request prior to handing to an admit
// function
func serve(w http.ResponseWriter, r *http.Request, admit admitHandler) {
	var body []byte
	if r.Body != nil {
		if data, err := ioutil.ReadAll(r.Body); err == nil {
			body = data
		}
	}

	// verify the content type is accurate
	contentType := r.Header.Get("Content-Type")
	if contentType != "application/json" {
		log.Error().Msgf("contentType=%s, expect application/json", contentType)
		return
	}

	log.Info().Msgf("handling request: %s", body)
	var responseObj runtime.Object
	if obj, gvk, err := deserializer.Decode(body, nil, nil); err != nil {
		msg := fmt.Sprintf("Request could not be decoded: %v", err)
		log.Error().Msg(msg)
		http.Error(w, msg, http.StatusBadRequest)
		return

	} else {
		requestedAdmissionReview, ok := obj.(*admission.AdmissionReview)
		if !ok {
			log.Error().Msgf("Expected v1.AdmissionReview but got: %T", obj)
			return
		}
		responseAdmissionReview := &admission.AdmissionReview{}
		responseAdmissionReview.SetGroupVersionKind(*gvk)
		responseAdmissionReview.Response = admit.v1(*requestedAdmissionReview)
		responseAdmissionReview.Response.UID = requestedAdmissionReview.Request.UID
		responseObj = responseAdmissionReview

	}
	log.Info().Msgf("sending response: %v", responseObj)
	respBytes, err := json.Marshal(responseObj)
	if err != nil {
		log.Err(err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	if _, err := w.Write(respBytes); err != nil {
		log.Err(err)
	}
}

func serveMutate(w http.ResponseWriter, r *http.Request) {
	serve(w, r, AdmitHandler(mutate))
}
func serveValidate(w http.ResponseWriter, r *http.Request) {
	serve(w, r, AdmitHandler(validate))
}

type patchOperation struct {
	Op    string      `json:"op"`
	Path  string      `json:"path"`
	Value interface{} `json:"value,omitempty"`
}

// adds prefix 'prod' to every incoming Deployment, example: prod-apps
func mutate(ar admission.AdmissionReview) *admission.AdmissionResponse {
	log.Info().Msgf("mutating cegp")
	/*
		deploymentResource := metav1.GroupVersionResource{Group: "apps", Version: "v1", Resource: "deployments"}
		if ar.Request.Resource != deploymentResource {
			log.Error().Msgf("expect resource to be %s", deploymentResource)
			return nil
		}
	*/

	raw := ar.Request.Object.Raw

	cegp := v2.CiliumEgressGatewayPolicy{}
	if _, _, err := deserializer.Decode(raw, nil, &cegp); err != nil {
		log.Err(err)
		return &admission.AdmissionResponse{
			Result: &metav1.Status{
				Message: err.Error(),
			},
		}
	}
	eg := &v2.EgressGateway{
		NodeSelector: &slimv1.LabelSelector{
			MatchLabels: map[string]slimv1.MatchLabelsValue{
				"aa": "cc",
			},
		},
		EgressIP: "2.2.2.2",
	}
	fmt.Printf("get cegp name: %+v\n", cegp.Name)

	/*
		egj, err := json.Marshal(eg)
		if err != nil {
			fmt.Println(err)
			return &admission.AdmissionResponse{
				Result: &metav1.Status{
					Message: err.Error(),
				},
			}
		}
		fmt.Println("egj:", string(egj))
	*/

	pt := admission.PatchTypeJSONPatch
	pto := []patchOperation{
		{
			Op:    "add",
			Path:  "/spec/egressGateway",
			Value: eg,
		},
	}

	ptj, err := json.Marshal(pto)
	if err != nil {
		fmt.Println(err)
		return &admission.AdmissionResponse{
			Result: &metav1.Status{
				Message: err.Error(),
			},
		}
	}

	//egPatch := fmt.Sprintf(`[{ "op": "add", "path": "/spec/egressGateway", "value": "%s" }]`, string(egj))
	return &admission.AdmissionResponse{Allowed: true, PatchType: &pt, Patch: ptj}
}

// verify if a Deployment has the 'prod' prefix name
func validate(ar admission.AdmissionReview) *admission.AdmissionResponse {
	log.Info().Msgf("validating deployments")
	deploymentResource := metav1.GroupVersionResource{Group: "apps", Version: "v1", Resource: "deployments"}
	if ar.Request.Resource != deploymentResource {
		log.Error().Msgf("expect resource to be %s", deploymentResource)
		return nil
	}
	raw := ar.Request.Object.Raw
	deployment := appsv1.Deployment{}
	if _, _, err := deserializer.Decode(raw, nil, &deployment); err != nil {
		log.Err(err)
		return &admission.AdmissionResponse{
			Result: &metav1.Status{
				Message: err.Error(),
			},
		}
	}
	if !strings.HasPrefix(deployment.GetName(), "prod-") {
		return &admission.AdmissionResponse{
			Allowed: false, Result: &metav1.Status{
				Message: "Deployment's prefix name \"prod\" not found",
			},
		}
	}
	return &admission.AdmissionResponse{Allowed: true}
}

func main() {
	log.Info().Msg("Server started ...333")
	var tlsKey, tlsCert string
	flag.StringVar(&tlsKey, "tlsKey", "/etc/certs/tls.key", "Path to the TLS key")
	flag.StringVar(&tlsCert, "tlsCert", "/etc/certs/tls.crt", "Path to the TLS certificate")
	flag.Parse()

	// creates the in-cluster config
	config, err := rest.InClusterConfig()
	if err != nil {
		panic(err.Error())
	}
	// creates the clientset
	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		panic(err.Error())
	}
	for {
		// get pods in all the namespaces by omitting namespace
		// Or specify namespace to get pods in particular namespace
		pods, err := clientset.CoreV1().Pods("").List(context.TODO(), metav1.ListOptions{})
		if err != nil {
			fmt.Printf("error11: %+v\n", err)
			time.Sleep(7 * time.Second)
			continue
		} else {
			fmt.Printf("There are %d pods in the cluster\n", len(pods.Items))
		}

		cli, err := ciliumv2.NewForConfig(config)
		if err != nil {
			panic(err.Error())
		}

		res, err := cli.CiliumEgressGatewayPolicies().List(context.TODO(), metav1.ListOptions{})

		if err != nil {
			fmt.Printf("error78: %+v\n", err)
			return
		}
		fmt.Printf("result: %+v\n", res)

		result3 := &cv1.PodList{}
		err = clientset.RESTClient().Get().
			Namespace("test").
			Resource("pods").
			VersionedParams(&metav1.ListOptions{}, scheme.ParameterCodec).
			Do(context.TODO()).
			Into(result3)

		if err != nil {
			fmt.Printf("error33: %+v\n", err)
			time.Sleep(7 * time.Second)
			continue

		}

		fmt.Printf("result3: %+v\n", result3)

		li, err := clientset.CoreV1().Pods("test").List(context.TODO(), metav1.ListOptions{})
		if err != nil {
			fmt.Printf("error: %+v\n", err)
			return
		}
		fmt.Printf("li: %+v\n", li.Items[0])
		_, err = clientset.CoreV1().Pods("default").Get(context.TODO(), "example-xxxxx", metav1.GetOptions{})
		if errors.IsNotFound(err) {
			fmt.Printf("Pod example-xxxxx not found in default namespace\n")
		} else if statusError, isStatus := err.(*errors.StatusError); isStatus {
			fmt.Printf("Error getting pod %v\n", statusError.ErrStatus.Message)
		} else if err != nil {
			panic(err.Error())
		} else {
			fmt.Printf("Found example-xxxxx pod in default namespace\n")
		}

		time.Sleep(7 * time.Second)
	}

	return
	// build the client set

	/*
		clientSet, err := clientset.NewForConfig(config)
		//	clientSet, err := kubernetes.NewForConfig(config)
		if err != nil {
			fmt.Printf("Fail to create the k8s client set. Errorf - %s", err)
			return
		}

		//	clientset.Discovery().RESTClient()
		cli := cv2.New(clientSet.RESTClient())
		gw := cli.CiliumEgressGatewayPolicies()

		//path := fmt.Sprintf("/apis/operators.coreos.com/v1alpha1/namespaces/%s/clusterserviceversions", "test")

		result := &v2.CiliumEgressGatewayPolicyList{}
		err = clientSet.RESTClient().Get().
			Resource("ciliumegressgatewaypolicies").
			Do(context.Background()).
			Into(result)

		if err != nil {
			fmt.Printf("err123: %+v\n", err)

		} else {
			fmt.Printf("data: %+v\n", result)
		}

		po, err := gw.List(context.Background(), mv1.ListOptions{
			Limit: 10,
		})
		if err != nil {
			fmt.Printf("err123: %+v\n", err)

		}
		fmt.Printf("gw policy: %+v \n", po)
		http.HandleFunc("/mutate", serveMutate)
		http.HandleFunc("/validate", serveValidate)

		log.Fatal().Err(http.ListenAndServeTLS(":8443", tlsCert, tlsKey, nil)).Msg("webhook server exited")

	*/
}

#!/bin/bash
set -e
go build -o hello
docker cp hello cilium-worker:/root/go-code/helloworld/hello

docker cp hello cilium-worker2:/root/go-code/helloworld/hello


docker cp hello cilium-control-plane:/root/go-code/helloworld/hello
kubectl rollout restart deploy webhook-server
sleep 2 
kubectl get pod 
